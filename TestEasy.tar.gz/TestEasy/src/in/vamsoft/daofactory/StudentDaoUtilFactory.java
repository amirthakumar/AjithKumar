package in.vamsoft.daofactory;

import in.vamsoft.testutil.StudentDaoUtil;

public class StudentDaoUtilFactory {

  
  public static StudentDaoUtil createInstance()
  {
    return new StudentDaoUtil();
    
    
  }
  
  
}
